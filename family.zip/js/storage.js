/*
==========================================
        Family😍 Messenger
        storage.js
==========================================
*/

const Storage = {

    key: "FamilyMessenger",

    database: null,

    createDatabase(){

        return{

            users:[],

            globalChat:[],

            privateChats:{},

            settings:{}

        };

    },

    load(){

        const json =

            localStorage.getItem(

                this.key

            );

        if(!json){

            this.database =

                this.createDatabase();

            this.save();

            return;

        }

        try{

            this.database =

                JSON.parse(json);

        }

        catch{

            this.database =

                this.createDatabase();

            this.save();

        }

    },

    save(){

        localStorage.setItem(

            this.key,

            JSON.stringify(

                this.database

            )

        );

    },

    reset(){

        this.database =

            this.createDatabase();

        this.save();

    },

    /*=========================
            USERS
    =========================*/

    getUsers(){

        return this.database.users;

    },

    saveUsers(users){

        this.database.users = users;

        this.save();

    },

    /*=========================
            GLOBAL CHAT
    =========================*/

    getGlobalMessages(){

        return this.database.globalChat;

    },

    saveGlobalMessages(messages){

        this.database.globalChat = messages;

        this.save();

    },

    /*=========================
            PRIVATE CHAT
    =========================*/

    getPrivateChat(chatId){

        if(

            !this.database.privateChats[chatId]

        ){

            this.database.privateChats[chatId]=[];

        }

        return this.database.privateChats[chatId];

    },

    savePrivateChat(

        chatId,

        messages

    ){

        this.database.privateChats[chatId]=messages;

        this.save();

    },

    /*=========================
            SETTINGS
    =========================*/

    getSettings(){

        return this.database.settings;

    },

    saveSettings(settings){

        this.database.settings=settings;

        this.save();

    }

};

Storage.load();