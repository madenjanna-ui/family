/*
==========================================
        Family😍 Messenger
        app.js
==========================================
*/

const App = {

    start(){

        if(

            Auth.autoLogin()

        ){

            this.showHome();

        }

        else{

            this.showLogin();

        }

    },

    /*=========================
            LOGIN
    =========================*/

    showLogin(){

        app.innerHTML = `

        <div class="login">

            <div class="logo">

                😍

            </div>

            <div class="title">

                Family

            </div>

            <div class="subtitle">

                Семейный мессенджер

            </div>

            <input

                id="login"

                placeholder="Логин"

            >

            <input

                id="password"

                type="password"

                placeholder="Пароль"

            >

            <button

                class="primary"

                onclick="App.login()">

                Войти

            </button>

        </div>

        `;

    },

    login(){

        const login =

            document

            .getElementById("login")

            .value

            .trim();

        const password =

            document

            .getElementById("password")

            .value

            .trim();

        if(

            Auth.login(

                login,

                password

            )

        ){

            this.showHome();

        }

        else{

            alert(

                "Неверный логин или пароль"

            );

        }

    },

    /*=========================
            HOME
    =========================*/

    showHome(){

        const user =

            Auth.currentUser;

        app.innerHTML = `

        <div class="page">

            <div class="header">

                <h1>

                    😍 Family

                </h1>

                <button

                    onclick="App.logout()">

                    Выйти

                </button>

            </div>

            <div class="content">

                <div class="card">

                    👋 Добро пожаловать,

                    <b>${user.name}</b>

                </div>

                <div

                    class="card"

                    onclick="App.openGlobalChat()">

                    💬 Общий чат

                </div>

                <div

                    class="card"

                    onclick="App.openUsers()">

                    👤 Личные сообщения

                </div>

                ${

                    Auth.isAdmin()

                    ?

                    `

                    <div

                        class="card"

                        onclick="App.openAdmin()">

                        👑 Пользователи

                    </div>

                    `

                    :

                    ""

                }

            </div>

        </div>

        `;

    },

    logout(){

        Auth.logout();

        this.showLogin();

    },

    /*=========================
            TEMP
    =========================*/

    openGlobalChat(){

        alert(

            "Следующий файл 😊"

        );

    },

    openUsers(){

        alert(

            "Следующий файл 😊"

        );

    },

    openAdmin(){

        alert(

            "Следующий файл 😊"

        );

    }

};

const app =

document.getElementById(

    "app"

);

App.start();