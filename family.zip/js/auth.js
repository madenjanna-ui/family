/*
==========================================
        Family😍 Messenger
        auth.js
==========================================
*/

const Auth = {

    currentUser:null,

    init(){

        const users = Storage.getUsers();

        if(users.length===0){

            users.push({

                id:1,

                name:"Администратор",

                login:"admin",

                password:"admin",

                admin:true

            });

            Storage.saveUsers(users);

        }

    },

    login(login,password){

        const users = Storage.getUsers();

        const user = users.find(u=>{

            return (

                u.login===login &&

                u.password===password

            );

        });

        if(!user){

            return false;

        }

        this.currentUser=user;

        localStorage.setItem(

            "FamilySession",

            JSON.stringify(user)

        );

        return true;

    },

    autoLogin(){

        const session =

        localStorage.getItem(

            "FamilySession"

        );

        if(!session){

            return false;

        }

        try{

            this.currentUser=

                JSON.parse(session);

            return true;

        }

        catch{

            return false;

        }

    },

    logout(){

        this.currentUser=null;

        localStorage.removeItem(

            "FamilySession"

        );

    },

    isAdmin(){

        if(!this.currentUser){

            return false;

        }

        return this.currentUser.admin;

    },

    createUser(

        name,

        login,

        password

    ){

        if(!this.isAdmin()){

            return false;

        }

        const users =

            Storage.getUsers();

        if(

            users.find(

                u=>u.login===login

            )

        ){

            return false;

        }

        users.push({

            id:Date.now(),

            name,

            login,

            password,

            admin:false

        });

        Storage.saveUsers(users);

        return true;

    },

    getUsers(){

        return Storage.getUsers();

    }

};

Auth.init();